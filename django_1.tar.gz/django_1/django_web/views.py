from django.shortcuts import render
from django_web import models
from django.http import HttpResponse,HttpResponseRedirect
import urllib.parse
import pymysql

def change(top):
    data = []
    A = []
    for i in top:
        A.append(i[0])
        A.append(int(i[1]))
        data.append(A)
        A = []

    return data


start_major = {
    1:'不适用',
    2:'较不适用',
    3:'基本一致',
    4:'较一致',
    5:'高度适用',
}


start_certificate = {
    1:'较不相关',
    2:'行业性相关',
    3:'基本相关',
    4:'较相关',
    5:'高度相关',
}



def index(request):
    context = {
        'major':models.Major[1:],
        'post': models.Post,
        'certificate': models.Certificate[1:],
        'trade':models.Trade[1:],
    }

    return render(request, 'index.html',context)




def result_post(request):
    POST = urllib.parse.quote(request.GET['post'])
    MAJOR = urllib.parse.quote(request.GET['major'])
    CERTIFICATE = urllib.parse.quote(request.GET['certificate'])
    # DATA = POST + MAJOR + CERTIFICATE
    # print (MAJOR)
    response = HttpResponseRedirect('/post_major/')
    response.set_cookie('major', MAJOR , 3600)
    response.set_cookie('post', POST, 3600)
    response.set_cookie('certificate', CERTIFICATE, 3600)
    return response





def post_major(request):
    post = request.COOKIES.get('post','')
    post2 = str(urllib.parse.unquote(post)).split(',')
    major = request.COOKIES.get('major','')
    major2 = str(urllib.parse.unquote(major)).split(',')
    # print (major2,post2)

    user = 'root'
    passwd = '123'

    conn = pymysql.connect(host='127.0.0.1', user=user, passwd=passwd, db='data2', charset='utf8')
    cur = conn.cursor()

    sql = 'select zhuanye,shus from _20L_pm where gangwei=%s'
    params = (post2[0])

    cur.execute(sql,params)
    top_post = cur.fetchall()

    cur.close()
    conn.close()


    # print (top_post)
    start = models.pingFen('post_major',post2,major2)

    context = {
        'post':post2[0],
        'major':major2,
        'top_post':change(top_post),
        'start':start,
        'start_major':start_major[start],
    }

    return render(request,'post_major.html',context)




def post_cer(request):
    post = request.COOKIES.get('post','')
    post2 = str(urllib.parse.unquote(post)).split(',')
    cer = request.COOKIES.get('certificate','')
    cer2 = str(urllib.parse.unquote(cer)).split(',')

    user = 'root'
    passwd = '123'

    conn = pymysql.connect(host='127.0.0.1', user=user, passwd=passwd, db='data2', charset='utf8')
    cur = conn.cursor()

    sql = 'select zhengshu,shus from _20L_pc where gangwei=%s'
    params = (post2[0])

    cur.execute(sql,params)
    top_post = cur.fetchall()

    cur.close()
    conn.close()


    # start = models.pingFen('post_major',post2,major2)
    context = {
        'post':post2[0]
    }

    return render(request,'post_cer.html',context)