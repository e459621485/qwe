from django.db import models
import pymysql



user = 'root'
passwd = '123'

conn = pymysql.connect(host='127.0.0.1',user=user,passwd=passwd,db='data2',charset='utf8')
cur = conn.cursor()

sql = 'select major from major'

reCont = cur.execute(sql)
major = cur.fetchall()


sql = 'select gangWei from _gangWei'

reCont = cur.execute(sql)
post = cur.fetchall()

sql = 'select certificate from certificate group by certificate'

reCont = cur.execute(sql)
certificate = cur.fetchall()

sql = 'select trade from trade'

reCont = cur.execute(sql)
trade = cur.fetchall()

cur.close()
conn.close()

Major = []
Post = []
Certificate = []
Trade = []


def bianbian(A,B):
    for i in B:
        A.append(i[0])

bianbian(Major,major)
bianbian(Post,post)
bianbian(Trade,trade)
bianbian(Certificate,certificate)








def pingFen(table,hangYeUser=[], zhuanYeUser=[]):   #第一个参数是用户的行业， 第二个是用户的专业
    conn = pymysql.connect(host='127.0.0.1', user=user, passwd=passwd, db='data2', charset='utf8')
    cur = conn.cursor()
    if table == 'post_major':
        sql = 'select * from _20L_pm'
    elif table == 'post_certificate':
        sql = 'select * from _20L_pc'
    elif table == 'trade_major':
        sql = 'select * from _20L_im'
    elif table == 'trade_certificate':
        sql = 'select * from _20L_ic'
    # params = (table)
    cur.execute(sql)
    results = cur.fetchall()
    y1 = 0
    y2 = []
    x = 0
    for h, i, j, k, m in results:
        if i in hangYeUser:
            x = x + int(k)
            y2.append(x)

        if i in hangYeUser and j in zhuanYeUser:
            y1 = y1 + int(k)

    a = y1/x
    b = y2[0]/x
    c = max(b,0.2)
    if a>=c:
        return 5
    if a==0:
        return 1
    if 0<a and a<0.1:
        return 2
    if 0.1<=a and a<0.2:
        return 3
    if 0.2<=a and a<c:
        return 4
    cur.close()
    conn.close()







#
# class Data(models.Model):
#
#     id = models.IntegerField()
#
#     major1 = models.CharField(max_length=50)
#




# print(Trade)
# print(zl_tiao)
# # Create your models here.
