#!/usr/bin/python
# -*- coding: UTF-8 -*-

import pymysql

user = 'root'
passwd = '123'

conn = pymysql.connect(host='127.0.0.1',user=user,passwd=passwd,db='data',charset='utf8')
cur = conn.cursor()

sql = 'select gangwei from pm_top_20_2 group by gangwei'


reCont = cur.execute(sql)
conn.commit()

cur.close()
conn.close()

print(reCont)
