"""django_1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
# from django.contrib import admin
# from django_web.views import chart2
# from django_web.views import Jd_data
# from django_web.views import Tb_data
# from django_web.views import chart3
# from django_web.views import chart4
# from django_web.views import chart5
from django_web.views import index
from django_web import views

urlpatterns = [
    # url(r'^admin/', admin.site.urls),
    url(r'^index/', views.index,name = 'index'),
    # url(r'^chart1/', views.chart1),
    # url(r'^chart2/', chart2),
    # url(r'^jd_data/', Jd_data),
    # url(r'^tb_data/', Tb_data),
    # url(r'^chart3/', chart3),
    url(r'^post_certificate/', views.post_cer,name='post_cer'),
    url(r'^post_major/',  views.post_major,name='post_major'),
    url(r'^result/', views.result_post,name = 'result'),
    url(r'^result2/', views.result_post,name = 'result2'),
]
